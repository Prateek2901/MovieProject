A Pen created at CodePen.io. You can find this one at http://codepen.io/Prateek_1996/pen/aBewjE.

 